package com.bd.dipti.TestSpringSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
